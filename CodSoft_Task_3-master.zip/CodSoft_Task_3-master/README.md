# ATM Interface
Task-3: ATM Interface 
<br/>
Language: Core Java
<br/>
IDE: Netbeans
<br/>
My Task is to implement a simple ATM interface that allows users to withdraw, deposit, and check their balance. It also includes a main menu that allows users to select their desired option.
<br/>
<h1>Demo Video: </h1>




https://github.com/deblinaroy11/CodSoft_Task_3/assets/137715845/e02c23d3-9d77-4c6b-b54a-80c529b2b79a

<h1>Snapshot: </h1>


![1](https://github.com/deblinaroy11/CodSoft_Task_3/assets/137715845/fd7c38d0-ac90-4446-ad29-38aca12aec8a)
![2](https://github.com/deblinaroy11/CodSoft_Task_3/assets/137715845/63330161-e886-4132-9f78-ffa2a5ee3485)
![3](https://github.com/deblinaroy11/CodSoft_Task_3/assets/137715845/3023a573-0556-4015-a9f5-c2a5172a573d)
![4](https://github.com/deblinaroy11/CodSoft_Task_3/assets/137715845/73522ab5-a127-40e0-ba7c-30c45b3a6fad)
![5](https://github.com/deblinaroy11/CodSoft_Task_3/assets/137715845/05da5ac2-2ad9-4371-8319-09e8a52812f4)
![6](https://github.com/deblinaroy11/CodSoft_Task_3/assets/137715845/6b3d1535-af07-4810-8eb2-c0a9cf31aad4)
![7](https://github.com/deblinaroy11/CodSoft_Task_3/assets/137715845/4b42607f-b4ab-4459-b653-7c6bc9b796f2)
